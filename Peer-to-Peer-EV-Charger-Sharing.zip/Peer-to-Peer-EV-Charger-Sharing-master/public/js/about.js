// Lights up the photo when hovered.
$('#edwin')
	.mouseover(function () {
		$(this).attr("src", "../images/edwin2.gif");
	})
	.mouseout(function () {
		$(this).attr("src", "../images/edwin.gif");
	});

$('#alex')
	.mouseover(function () {
		$(this).attr("src", "../images/alex2.gif");
	})
	.mouseout(function () {
		$(this).attr("src", "../images/alex.gif");
	});

$('#vivian')
	.mouseover(function () {
		$(this).attr("src", "../images/vivian2.gif");
	})
	.mouseout(function () {
		$(this).attr("src", "../images/vivian.gif");
	});

$('#eric')
	.mouseover(function () {
		$(this).attr("src", "../images/eric2.gif");
	})
	.mouseout(function () {
		$(this).attr("src", "../images/eric.gif");
	});

$('#louis')
	.mouseover(function () {
		$(this).attr("src", "../images/louis2.gif");
	})
	.mouseout(function () {
		$(this).attr("src", "../images/louis.gif");
	});